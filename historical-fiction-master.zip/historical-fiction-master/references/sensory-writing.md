# Sensory Writing Reference

*Called from: SKILL.md nodes A3, A4, A5, G3*
*Links back to: SKILL.md A-node (immersion engine), G3 (sensory audit)*
*Links forward to: period-voice.md (sound in dialogue); character-biography.md (body as archive)*

## The Governing Principle

A book is a silent object. It has no smell, no warmth, no sound. And yet when a reader opens it, as many senses are awakened as the author chooses to evoke. The author's obligation is to evoke *all of them*. A page that activates only the eye is a page that wastes four senses.

The core instruction: **Write to their senses.**

This is not a stylistic preference. It is the primary mechanism of temporal immersion. Sensory detail is the thing that puts the reader inside a body in another time. Everything else — research, period vocabulary, structural elegance — serves this.

---

## The Five Senses: Deployment Guide

### 1. Hearing

Sound is the most neglected sense in prose and one of the most powerful. Historical life was radically noisy — before recorded sound, people made their own music; before sealed buildings, the world pressed in through every gap; before internal combustion, the soundscape was completely unlike our own.

**Techniques:**
- Name the *specific* instrument, not just "music" — a hautboy, a hurdy-gurdy, a jaw harp, a bodhran, a tamboura each produce a different sound, a different social meaning, and a different era
- Use description that forces the reader to construct the sound internally: not "loud drums" but "the deep, belly-felt throb of kettledrums two hundred yards away, arriving a half-beat after the flash"
- Coin original similes for sound: an artillery shell described by an actual witness as sounding like "canvas being ripped across the sky overhead" — specific, accurate, and fresh. "The screaming shell" has been written ten thousand times
- Use song fragments structurally — a melody heard in passing can foreshadow, evoke memory, mark time, establish class, plant an omen
- Let sound reveal what vision cannot: the thing behind the wall, the distance of a threat, the hour of night, the size of a space by its echo

**Communication as sound:** The town crier walking the streets announcing the news; the drum signal from the ridge; the semaphore flag in the distance; the bell-tower cannon that marks a ship's arrival. The mode of public communication in any era is a *sound event* as much as an information event. Research what it sounded like.

**The period soundscape:** Research the specific ambient sound of your time and place. A medieval city smells of animals and sounds of hooves, church bells, street sellers, and the constant percussion of craft work — smiths, coopers, cobblers. A Revolutionary War camp sounds of fife and drum at reveille, axe-work all morning, and at night the distant owl and the near breathing of two hundred cold men.

### 2. Smell

Smell is the most powerful memory trigger the human brain possesses. A scent not encountered since childhood can reconstruct an entire emotional world in an instant. On the page, a well-chosen smell anchors the reader in a time and place more firmly than any date.

**The historical reality:** Past eras smelled profoundly different from our own. The absence of running water, refrigeration, antiseptic, and deodorant meant that bodies, streets, kitchens, stables, battlefields, and sickrooms produced smells that are now almost inaccessible to modern experience. This is a research subject, not merely a stylistic one.

**Categories to research:**
- Medical and pharmaceutical: tar water, camphor, tobacco smoke used medicinally, vinegar rations, sulphur, mercury treatments, the smell of a dressing left too long
- Domestic: tallow candles versus beeswax, wood smoke versus coal, lye soap made with wood ash, rendered fat, the specific smell of a particular grain fermenting or bread baking
- Battlefield: black powder residue, blood on cold ground, unwashed wool, fear-sweat, putrefaction downwind
- Food preparation: curing meat with salt and smoke, green wood fires, period-specific spices, the vinegar of preservation
- Trade and craft: the smithy (hot iron and coal), the tannery (urine and hide), the apothecary (herbs and alcohol), the printer's workshop (ink and linseed oil and the particular warmth of a press)

**Technique:** Introduce smell through the character's *reaction*, not as neutral catalogue. A smell that makes the character remember something, recoil, feel safe, or grow uneasy is doing double work — sensory detail plus character revelation.

### 3. Touch and Temperature

Touch is the most intimate sense — it requires proximity, even contact. It therefore places the reader most completely inside a body. Temperature is touch's most pervasive form.

**Temperature as period reality:** Central heating, thermal clothing, and climate control are recent. Cold, in most of recorded history, was a genuine physical adversary that shaped decisions, morale, survival, and death. Heat, humidity, and the specific texture of period materials against skin are equally significant.

**Technique:**
- Let the character feel the world, not merely see it: the grain of rough-hewn timber, the chill of stone flags underfoot at three in the morning, the particular weight of damp wool, the slickness of oiled leather in rain
- Temperature under physical stress — marching in cold, fever in a sickroom, working a smithy in July — reveals the body's experience of history in a way no abstract description matches
- Period clothing creates specific sensory experiences: whalebone stays, identical boots (no left or right), linen shifts that cling when wet, breeches that chafe. These are historical facts embedded in the flesh
- The body as archive: old wounds that ache in cold; the chronic cough; the way a character moves to protect an injury without thinking about it

### 4. Taste

Taste is the most intimate sense of all — it requires the world to enter the body. It is therefore among the most powerful anchors of place and time.

**Research areas:**
- What was available and what was not (spice routes, seasonal availability, preservation methods, the absence of refrigeration)
- The actual flavour of period food and drink differs significantly from modern versions: unselected grain, herbed ale, salt-preserved meat, no refined sugar in quantity for most of history
- Medical treatments administered by taste: vinegar rations, rum as anaesthetic and antiseptic, medicinal teas, the particular bitterness of period remedies
- The difference between poverty and abundance in the mouth: thin gruel versus roast meat, hardtack versus fresh bread, water that tastes of the barrel or the river it came from

**Technique:** Taste works best as an unexpected arrival — the character biting into something they expected and getting something else, or tasting for the first time something that has no equivalent in their experience.

### 5. Sight: The Overused Sense

Sight is what most writers default to and therefore the sense least in need of instruction. However:
- Visual detail must be *specific* and *era-accurate*: not "the trees" but the correct species for that region and climate; not "the uniform" but the specific cut, colour, and insignia that a specialist would recognise
- Light sources determine the quality of vision: tallow candle, rush light, beeswax, whale-oil lamp, open fire — each produces a different colour and quality of illumination that changes everything seen by it
- Do not catalogue visual details; let the character's attention move naturally, drawn by what is relevant to their current state of mind, fear, or purpose

---

## The "Good Yucky Stuff" Principle

The biological, accidental, and disgusting details of historical life carry an authority that no invented dramatic detail can match. They are the proof of research, the signal of authenticity, and the detail that lodges in the reader's memory long after everything else fades.

**Why it works:** A reader who is surprised by a detail they could not have invented — who thinks "I had no idea that happened / was used / was true" — has been pulled fully into the historical world. The yucky stuff bypasses the reader's sceptical apparatus because it is too specific and too unglamorous to have been made up.

**Categories to hunt in your research:**
- Medical treatments and their materials: what was used, how it worked (or didn't), what it smelled and tasted and felt like
- Food preservation and its failures: mould, weevils, rancidity, the taste of food that was technically still edible
- Bodily processes in conditions without sanitation: the reality of army camps, crowded ships, prisons, hospitals, long journeys
- Accidents of craft and manufacture: the byproducts of tanning, dyeing, rendering, fermenting, smelting
- The specific grotesque details of wounds, disease, and their treatment before modern medicine

**Rule:** In every chapter, ask: what is the biological, accidental, or grotesque truth that a sanitised account would leave out? Find it in primary sources — it will always be there. Include it. It will do more work than any carefully crafted dramatic effect.

---

## Music as Structural Device

In all periods before recording, music was central to daily life in a way modern audiences underestimate. Before literacy was universal, songs carried memory, theology, law, history, and grief.

**Uses in historical fiction:**
- **Foreshadowing:** A lyric fragment heard in passing that acquires terrible or joyful resonance at the end
- **Characterisation:** What a character sings, or what moves them in song, reveals them more directly than description
- **Social marker:** Music defines class, region, religion, and occasion with more precision than three paragraphs of description
- **Emotional amplification:** A familiar melody in an unfamiliar moment creates dissonance or poignancy that the scene alone cannot achieve
- **Period authenticity:** The correct song at the correct moment tells the reader the writer knows

**Technique:** A song lyric read from the page goes to the reader's brain, where it is "heard." The mental ear is as real as the physical one. Write song fragments with the same care as any prose passage.

---

## The Original Simile Obligation

Every sensory description should aim for a simile or image that is:
1. **Original** — not a phrase worn smooth by overuse
2. **Accurate** — verified against how the thing actually sounds, smells, feels
3. **Available to the character** — drawn from reference points the character actually possesses

A frontier soldier of 1778 cannot compare a sound to a chainsaw. He can compare it to a mill wheel, a swollen river, a tree cracking under ice. The simile is itself a period document.

**Practice:** Wherever you are right now, describe one sound, one smell, and one texture in an original phrase. Not a recycled comparison — your own, made accurate. This is the daily exercise of the craft.

---

## Sensory Scene Checklist

| Sense | Present? | Dramatic weight? | Original? | Era-accurate? |
|-------|----------|-----------------|-----------|---------------|
| Sound | | | | |
| Smell | | | | |
| Touch / Temperature | | | | |
| Taste (where relevant) | | | | |
| Sight (specific) | | | | |
| Yucky stuff (per chapter) | | | | |

**Minimum standard:** Three senses present; one non-visual sense carrying dramatic weight; one yucky/biological/accidental truth per chapter.

---

## Cross-Links

- For material objects that activate touch, taste, smell: → **`subskills/period-texture-engine/period-texture-engine.md`**
- For period vocabulary to describe sensory experience: → **references/period-voice.md**
- For sound in dialogue (the mental ear): → **references/period-voice.md, section on dialogue**
- For the body as sensory archive of a character's history: → **references/character-biography.md, C3**
- For the audit that checks this work: → **SKILL.md, node G3**

# Period Voice Reference

*Called from: SKILL.md nodes D1–D5, G1, G6*
*Links back to: SKILL.md D-node and G-node; sensory-writing.md; character-biography.md*

## The Language Principle

Language is itself a historical artefact. The words, phrases, rhythms, and idioms available to a character in 1692 are different from those in 1842, which are different again from those in 1942. Every sentence a character speaks or thinks is a period document. If it contains an anachronism, it is a forgery.

But period voice is not simply a matter of avoiding modern slang. It is a matter of thinking, perceiving, and expressing from within the worldview and vocabulary of an era. A character in 1750 does not have a "trauma response." They have a distemper of the spirits. They do not "process their grief." They are afflicted with melancholy. The language is not merely decorative — it is the architecture of their consciousness.

**The language obligation:** Language is like fire — it enriches, illuminates, and is forever changing. Every writer who sets words down joins the oldest human tradition. To be lazy with language, to settle for the approximate word, to reach for the ready-made phrase instead of the precise one, is a failure of that obligation. Be worthy of it.

---

## Anachronism Prevention

### The Word-Date Problem
Many words and phrases that feel ancient are far younger than you think. Words that feel timeless are often freshly minted by the industrial age, the psychology movement, or the internet era.

**Standard practice:**
- Use a dictionary that cites year of first recorded use (the Oxford English Dictionary is the gold standard)
- Treat any word you cannot date to the period as suspect until verified
- Be especially suspicious of: psychological vocabulary, commercial vocabulary, sports metaphors, and any phrase that sounds like it could appear on a motivational poster

**Common anachronism categories:**

| Category | Examples | Notes |
|----------|----------|-------|
| Psychology | trauma, denial, closure, passive-aggressive, anxiety disorder, depression (clinical), toxic (person), boundary (personal) | Freudian framework: late 19th–early 20th century |
| Management | proactive, synergy, on the same page, bandwidth (metaphorical), skill set | 20th-century business culture |
| Sports metaphors | ballpark figure, level playing field, slam dunk, touch base, game plan | Baseball/basketball era American English |
| Modern idiom | no-brainer, game changer, wake-up call, heads-up, going forward, reach out | Late 20th century |
| Communication | wireless, on the wire, telegraph (before 1840s), phone (before 1870s) | Verify dates for your region |

**The state-of-knowledge test:** For any period before the 20th century, ask: is this knowledge articulable in the vocabulary of the time? The first edition of the *Encyclopaedia Britannica* (1769) records the state of knowledge of that era across arts, sciences, occupations, and philosophies. For earlier periods, consult period lexicons and glossaries.

### Anachronistic Attitudes
The most damaging anachronisms are not in the vocabulary but in the *attitudes*:
- Modern psychological self-awareness applied to pre-20th-century characters
- Characters speaking about social injustice in 21st-century analytical terms
- Characters rejecting the religious or supernatural explanations that governed their era as if they live in a secular modern world
- Characters behaving with an emotional intelligence their world had not yet developed

**The test:** Does this character believe the same things about human nature, illness, fate, and the social order that a person of their class, era, and region would believe? If not, they are a modern mind in historical dress — and that is the worst kind of anachronism.

---

## Period Cosmology in Language

How characters describe each other, explain events, and express emotion is governed by the explanatory framework of their era. This is not merely a vocabulary question — it is a *thinking* question.

**Pre-modern frameworks that must flavour period language:**

**The humours (operational c. 1300–1800):** Temperament explained by sanguine, phlegmatic, choleric, and melancholy dispositions governed by bodily fluids. "Bilious," "in a black mood," "of choleric temper," "sanguine about the prospect" — these were medical and social observations, not metaphors.

**Providence and divine will:** In most pre-Enlightenment periods, events were understood as expressions of God's plan, punishment, or testing. Characters do not attribute suffering to "bad luck" or "systemic failure" — they attribute it to Providence, sin, the Devil's work, or divine chastening.

**Fate, clan, and honour:** In many cultures and periods, the governing force of life was not individual psychology but collective obligation — clan loyalty, feudal duty, caste, honour. A character who violates this framework is not merely eccentric; they are a transgressor against the social order. That transgression has consequences the modern mind may not anticipate.

**Witchcraft, omens, and the supernatural:** In many periods, the supernatural was not metaphor but lived reality. A character who fears a witch's curse is not superstitious in the modern dismissive sense — they are operating rationally within the cosmology of their world. Write from inside that cosmology, not looking in at it.

---

## Codes and Mores: The Deadly Social Grammar

Every historical period had specific social codes that were not merely customs but life-and-death structures. A novelist who does not know the operating code of their era's social grammar will write characters who blunder through it invisibly — and thereby invisibly falsify the world.

### Duelling
From the 16th through the 19th century in Europe and America, a gentleman who could not control his tongue might face steel or a pistol ball at dawn. This single fact changes every scene of public debate, political argument, or personal insult in those centuries:

- A newspaper editor could be called to the field of honour for an editorial that modern journalism would consider routine criticism
- A political figure giving a speech had to calibrate every phrase against whether it constituted actionable insult
- Private correspondence could be read publicly and trigger a challenge
- The rituals of challenge (the glove, the second, the terms, the choice of weapons as the challenged party) had specific legal and social standing

**Research the specific code for your period:** What insults are forgivable and which are not? What triggers formal satisfaction? Who is exempt? How does class intersect with the code? (A gentleman could not duel with a tradesman without social cost; a woman could not be challenged; a clergyman occupied a complex position.)

### Other Period Social Codes to Research
- **Blood feuds:** The specific protocols of challenge, retaliation, and resolution in clan cultures
- **Guild obligations:** The legal standing of guild membership, the penalties for violation, the rituals of admission and expulsion
- **Religious oaths:** Their legal standing in courts, the social consequence of breaking them, the specific forms they took
- **Hospitality codes:** In many cultures and periods, hospitality was a legal and religious obligation with specific rules about who was owed it, for how long, and what protections it conferred
- **Sexual and domestic codes:** The specific legal and social standing of marriage, divorce, cohabitation, and adultery in your era — which varied enormously by class, region, and period

---

## Period Dialogue

### The Earworthiness Test
Dialogue is sound. The reader's mental ear hears it. Before any piece of dialogue is considered finished, read it aloud. If it sounds like a term paper wearing quotation marks, rewrite it. If no one in the history of human conversation has ever actually said something like this to another person's face, rewrite it.

### Dialogue That Earns Its Keep
**Purposes:** Advance action; reveal character through what is said *and* avoided; create conflict or tension; carry the sound of the period and class.

**Forbidden functions:**
- Describing to each other what both characters are currently looking at
- Explaining historical context to each other in ways no one actually speaks
- Adverbs attached to speech tags doing the work that tone and word choice should
- Eye dialect so aggressive it becomes unreadable

**The period dialogue test:** Could this sentence have been said, in this place, at this moment, by a person of this class and education? If not, rewrite.

### Fabricating Period Dialogue
1. **Research what was on their minds:** Documented letters and journals reveal the preoccupations of real figures. Invent dialogue consistent with that documented consciousness.
2. **Research the moment's context:** What was urgent in their world — the threat of war, the crop failure, the political crisis, the local scandal?
3. **Research the period idiom:** Collect phrases and constructions from primary sources. Even twenty pages of period letters will reveal sentence rhythm, address forms, and characteristic turns of thought.
4. **Apply the verisimilitude test:** Would it be strange if these people *didn't* have this conversation? If yes, the dialogue has verisimilitude.

### Dialect Without Distortion
Aggressive eye dialect — phonetic misspelling to represent accent — is harder to read than it is evocative. It patronises the speaker. It becomes unintentionally comic.

**The better method:** Convey dialect through period-accurate and region-accurate *idioms*, sentence rhythm and structure, and one or two carefully chosen non-standard words. The actual period phrase — the thing that people in that place and time actually said — carries more authority than any amount of apostrophe-work.

---

## Communication Technology Vocabulary

Characters in your period will have specific words for the communication technologies and information systems available to them. These are not merely props — they are part of the social and sensory fabric of their world.

**Research and include in your vocabulary list:**
- The specific name for the person who carries official news (herald, crier, express rider, courier, king's messenger, post rider)
- The name for the system of conveyance (post road, relay station, packet boat, express, semaphore line)
- What it sounded like when the news arrived (the town crier's bell, the rider's horn, the signal cannon, the drumbeat)
- The word for the document that carried news (broadsheet, gazette, letter, dispatch, warrant)
- The protocol for receiving and verifying official news (the seal, the counter-signature, the witness)

These vocabulary items belong in your period vocabulary list and should appear naturally in dialogue and narration when information arrives, is sought, or is withheld.

---

## Building a Period Voice: The Practical Process

1. **Collect a primary source corpus:** Gather 10–20 pages of primary-source writing from the era, region, and class of your characters. Read them aloud. Absorb the rhythm, the idiom, the characteristic turns of thought.
2. **Build your vocabulary list:** Extract phrases, idioms, and constructions. Note words and concepts that are *absent* — this tells you as much as what is present.
3. **Identify the explanatory framework:** Humours, providence, fate, honour, clan? How did people speak about health, misfortune, moral failure?
4. **Research the social code:** What are the specific life-and-death rules of social interaction in this era?
5. **Draft in period voice:** Write first-draft dialogue without stopping to verify every word. Then audit against your vocabulary list and the anachronism categories.
6. **Read aloud:** The mental ear is the final test.

---

## Cross-Links

- For material objects that accompany period speech: → **`subskills/period-texture-engine/period-texture-engine.md`**
- For social register in speech: → **`subskills/period-texture-engine/period-texture-engine.md`, social register section**
- For the character worldview underlying language: → **references/character-biography.md, belief and cosmology section**
- For sound as a sensory event in dialogue: → **references/sensory-writing.md, hearing section**
- For communication speed affecting what characters can say they know: → **references/research-methods.md, communication speed section**
- For the audit of period voice: → **SKILL.md, nodes G1, G6**

# Character Biography Reference

*Called from: SKILL.md nodes C1–C5, B3*
*Links back to: SKILL.md C-node; period-voice.md; truth-calibration.md; sensory-writing.md*

## The Actor Principle

Before writing a character, know them as an actor preparing to play them. An actor preparing to portray a real historical figure must answer questions the documentary record often cannot answer: What did this person's voice sound like? What did their face look like when they smiled? What were their physical peculiarities — not idealisations, but the specific details of their specific body?

These questions cannot be skipped. The novelist and the actor are doing the same work: bringing a specific human being to life with enough truth and specificity that the audience inhabits the same space as that person and believes in them absolutely.

## The White Heat of Character Preparation

Knowing a character's biography is necessary but not sufficient. At some point the novelist must cross from knowing *about* a character to *being* them — an act of imaginative possession that is closer to method acting than to academic preparation.

When this possession is achieved, the character begins to move independently. They find their own path through a scene. They refuse to do what the outline said, and the refusal is always more true than the plan was. They surprise the writer. This is the correct working state. The biography is the preparation; the white heat is the writing.

**Practice:** Before writing any significant scene involving a major character, spend five minutes inhabiting their body. What do they smell right now? What pain do they carry? What do they most dread in the next hour? What do they want so badly they have stopped naming it even to themselves? Then write from inside that body without looking back at the biography.

---

## The Body as Archive

A character's body is a document of everything that has happened to them. It is not a vessel for the mind — it *is* part of the mind, shaped by every wound, illness, hard winter, bad meal, and long march.

**The archive principle:** Every physical detail of a character's body has an origin, and that origin is historical:
- The old musket ball wound in the left shoulder that makes certain movements impossible
- The chronic cough from too many winters in damp tents with wet wool blankets
- The missing finger from a childhood accident at the cooperage
- The way the character automatically favours one side, without thinking, from an injury thirty years ago
- The man who must sleep propped upright because fluid in his lungs will not let him lie flat
- The woman whose wrists are scarred from rope burns she has never explained to anyone

None of these details are decorative. Each is the physical history of the person made present on every page. Write a body, and the reader will believe in a person.

**Research the period body:** Lifespan, prevalent diseases, available medicine, what injuries meant for a working life, the physical demands of the occupation. A blacksmith's hands are different from a clerk's. A soldier's spine is different from a merchant's. The body is a class document.

→ **Proceed to: `references/sensory-writing.md`** for activating the body through touch, pain, temperature, and physical history.

---

## The Biography Template

Use for every major character, real or invented. For real historical figures, fill by research. For invented characters, fill by rigorous period-grounded worldbuilding.

### Identity and Appearance
- **Name** (variants, nicknames, how different people address them — which itself reveals social relationship)
- **Age** at the novel's opening and at key moments
- **Physical appearance:** height, build, colouring, gait, posture, the specific distinguishing features that are odd or memorable — *not* generic attractiveness
- **Health and body archive:** chronic conditions, old injuries, dietary habits, physical strength and limitation, sensory impairments, the marks of occupation on the body
- **Voice:** pitch, accent, rhythm, volume, characteristic phrases, what it sounds like when they are angry versus afraid

### Origins and Formation
- **Place of birth and early environment:** not just the country but the specific landscape, climate, and built environment that formed their habits of body and perception
- **Family structure and position:** eldest, youngest, orphaned, the heir, the spare, the servant's child raised in the house
- **Economic circumstances of childhood:** what they owned, what they lacked, what they feared losing
- **Education:** formal and informal; what they read, what they were taught, what they taught themselves; crucially — whether they could read and write at all
- **Formative events:** the experiences that created the wound and the longing that drive them

### Belief and Cosmology
This section is the most often neglected and the most essential for avoiding anachronism of consciousness.

- **Religious belief and practice:** not just denomination but the texture of faith — devout, dutiful, doubting, or performative?
- **What governs their understanding of illness and health?** Humours, divine will, miasma, folk remedy, witchcraft, early science — the answer is era- and class-specific
- **What do they believe about fate?** Providence, luck, astrology, the clan's destiny, hard work, God's plan for them personally
- **What do they believe about their social position?** Natural order, deserved privilege, injustice to be borne, injustice to be resisted
- **What do they believe about people unlike them?** Other classes, races, sexes, faiths — the beliefs of their era, honestly rendered, not softened to modern palatability

**Critical rule:** Characters must hold the beliefs of their era. A 17th-century Puritan does not think in clinical psychology; they think in sin, grace, divine testing, and the Devil's work. A Roman soldier does not feel survivor's guilt; he may be haunted by omens and the displeasure of the gods. Giving characters anachronistic self-awareness betrays both the character and the history.

### Relationships and Social World
- **Primary relationships:** who they love, who they fear, who they depend on, who they have wronged
- **Social network:** allies, rivals, enemies, mentors, subordinates, the people they owe and who owe them
- **Social position and its obligations:** what is expected of them by class, sex, age, profession, and family
- **The social constraints on behaviour:** what they cannot do, say, or want without consequences — and how they navigate or resist those constraints

### Professional Knowledge
- **Occupation and its specific technical vocabulary:** what does this person know how to do that others do not?
- **What they know how to do with their hands:** ride, shoot, cook, navigate, calculate, negotiate, fight, heal, forge — the specific skills of their specific life
- **The knowledge that gives them power:** medical, financial, military, linguistic, social
- **The ignorance that limits them:** what they don't know that the reader may know — the dramatic irony available when a character cannot see what the reader can

### The Driver: Wound and Longing
Every compelling character is moved by a wound (something lost or never had) and a longing (the thing they are moving toward, consciously or not). The tension between these two is the engine.

- **The wound:** What happened, or failed to happen, that created the deficit at the character's core?
- **The longing:** What does this character want, more than anything, in this story?
- **The obstacle:** What stands between the wound and its healing?
- **The disguise:** How does the character conceal this wound and longing — from others, and from themselves?

---

## The Illiterate Protagonist

Through most of recorded history, most people could not read or write. A literate novelist writing an illiterate character must understand that illiteracy is not merely the absence of a skill — it is a fundamentally different relationship with memory, knowledge, perception, and the world.

**What illiteracy means for consciousness:**
- Knowledge is communicated entirely through story, song, demonstration, and accumulated observation — never through text
- Memory is extraordinary in domains where a literate person relies on notes: oral traditions carry genealogies, laws, histories, and medical knowledge with a precision literate people rarely achieve
- Spoken language is often richer, more rhythmically complex, and more idiomatically alive than that of educated literate speakers
- The landscape, weather, animal behaviour, and other people are perceived with an embodied immediacy that literacy can partially replace with abstraction — but only partially

**Navigation without text:** Polynesians navigated vast ocean distances between tiny islands using knowledge of stars, currents, cloud formations, and wave patterns — without charts or instruments. Australian Aboriginal peoples traversed an immense continent using memorised "road songs" — rhythmic sequences that encoded landmarks, water sources, and routes across the land. An illiterate character from many cultures possessed navigational and ecological knowledge that a literate modern person cannot easily replicate.

**The gift of illiteracy in fiction:** An illiterate protagonist sees everything with fresh, immediate, embodied intelligence. Nothing is abstracted onto a page. Everything is present, sensory, and alive. This can make them the most vividly present character in a novel full of literate people who move through the world at one remove.

**The research obligation:** Research the specific oral tradition, navigational knowledge, and craft knowledge of your character's community. The richness of what they know — and the specific things they do not know — will make them fully real.

---

## Children in History

Children's cries are the unheeded voices in the rumble of history. The historical novelist must resist the modern sentimentalisation of childhood. In most periods and most places, children were:

- **Economic units:** apprenticed from age seven or eight; sent into mines, mills, and factories; indentured to settle family debt; put on the streets to beg or sell
- **Political assets:** married off in childhood to seal alliances; traded as hostages; used as dynastic instruments with no more say in the matter than a piece of land
- **Legal non-persons:** subject to brutal discipline at home and school, with no legal protection against parents or masters; owned, in effect, until adulthood
- **Conscripts and victims of empire:** taken from their villages and sent to missionary schools without their parents' knowledge; language, culture, and name stripped from them by design; raised to serve a world that had not asked their permission
- **War's especial victims:** orphaned, conscripted into irregular forces, enslaved in the chaos of armies, killed in numbers that official histories record only as collateral

**The child narrator's specific power:** A child who witnesses adult events without fully understanding them creates a particular and irreplaceable dramatic irony — the reader knows what the child does not. Their incomprehension is not ignorance but a different kind of sight. War seen by a child, without the adult's rationalisation and accommodation, is often truer to the experience than any adult account.

**Research the period child:** Before writing any significant child character, research deep into the prevailing legal, economic, and emotional treatment of children in your era and class. Do not project modern child-protection values backward. Showing what was — without editorial softening — is more powerful than any judgment.

---

## Point of View Selection

### Real Figure as Protagonist
**Advantages:** Grounded in documented fact; the research has built-in depth; historical significance gives the story weight.
**Risks:** Beloved or contested figures attract specialists who will catch every error; the documented flaws may conflict with the writer's preferred portrayal; the available record can constrain invention uncomfortably.

**The research discipline:** Having assembled everything that can be known about the person, can you explain all their documented decisions and actions as the reasonable choices of a coherent human being? If a behaviour seems inexplicable, apply the Beagle Test and dig further. The person was coherent; the record is incomplete.

### Fictional Witness
A well-invented fictional character should be so specific and human that readers try to look them up. If readers assume they were real, the character is doing its job.

**Uses:** Gender balance; class perspective; the outsider's eye on events the protagonist takes for granted; a vehicle for subplot; the underrepresented voice that the official record does not contain.

**The test:** Can this invented character go places and see things that illuminate the real historical figure from angles the documented record does not provide? If yes, the fictional witness earns their place.

### Child Narrator
Specific advantages: sees war and power without adult rationalisation; the reader knows what the child does not; draws younger readers into historical learning; the child's ignorance is a source of dramatic irony that the writer can deploy precisely.

**The limit:** The child narrator must be a child of their time — not a modern child transported backward.

---

## Cross-Links

- For the language that flows from character worldview: → **references/period-voice.md**
- For the material objects and social register that reveal character: → **`subskills/period-texture-engine/period-texture-engine.md`**
- For the sensory detail that makes a character's body present: → **references/sensory-writing.md**
- For the period cosmology that governs character belief: → **references/period-voice.md, period cosmology section**
- For evaluating what a real historical figure would believe: → **references/truth-calibration.md**
- For the audit of character anachronism (especially illiterate/child characters): → **SKILL.md, G1 and G6**

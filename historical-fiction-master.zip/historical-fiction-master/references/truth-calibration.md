# Truth Calibration Reference

*Called from: SKILL.md nodes B4, F1–F5*
*Links back to: research-methods.md; SKILL.md F-node and G-node*

## The Nature of Historical Truth

Truth is always being modified. Anyone who sets out to tell history must first accept that the truth is elusive — not because it doesn't exist, but because every human agent involved in its transmission has a memory, a motive, and a perspective. Perception shapes record. Record shapes history. History shapes what can be imagined.

This is not a reason for relativism. The truth is the truth. Facts check the swing of the axe. But the historical novelist must begin with clear eyes about the ground they are standing on.

---

## The B.S. Filter

A well-trained historical mind possesses a specific sceptical reflex: when something in the historical record doesn't ring true — when a behaviour seems inexplicable, a cause is missing, an account doesn't quite cohere — the filter fires. This is not cynicism. It is pattern-recognition built from wide reading, immersion in the human record, and the habit of asking *why*.

**The Beagle Test:** Any historical account that doesn't quite make sense is missing a piece. Before accepting the gap as mere historical mystery:
1. Look for the missing piece in less-consulted primary sources
2. Ask whether the account was shaped by the teller's motive or memory
3. Consider whether the official version omitted something embarrassing or legally awkward
4. Follow the logic of human nature: people do not do inexplicable things; they do explicable things whose explanation has been lost

**The novelist's edge:** A generalist who casts a wide net sometimes catches what a specialist, confined to their own field, cannot see. A novelist's intuition — trained on human nature, sharpened by wide research, guided by the Beagle Test — is a legitimate instrument of historical inquiry. When a novelist catches a historian getting it wrong, it is usually because they followed the human logic further than the specialist was willing to go, or imported knowledge from an adjacent field that changed the picture.

---

## Source Credibility Evaluation

### The Primary Source Problem
Even eyewitness accounts are unreliable. The eyewitness saw from one position, remembered selectively, and may have been frightened, drunk, obligated to a patron, or writing for posterity in a way that flattered them. The closer a source is to the event, the more vivid and specific it tends to be — and the more partisan.

**Use primary sources for:** texture, vocabulary, sensory detail, the specific quirks of individual consciousness.
**Use secondary sources for:** structural understanding, chronology, the big picture.

### Conflicting Sources
When two credible sources disagree:
- **Check provenance:** Which source is closer in time and distance to the event?
- **Check motive:** Who benefits from each version?
- **Check the consensus of later scholarship:** Has the conflict been resolved?
- **Apply the human logic test:** Which version produces a story that makes human sense?
- **Apply the Beagle Test:** Is one version missing a piece that the other inadvertently supplies?

Record the conflict and your resolution in your source conflict log. If you choose the minority version, know why.

---

## The Official Narrative Problem

Official histories are written by the powerful, for the powerful, or in service of the powerful's self-image. This is not conspiracy — it is the structural reality of who had the tools, education, funding, and institutional support to create permanent records.

**What this means practically:**
- The defeated, the enslaved, the colonised, the oral-tradition keepers left fewer written records — but they are not absent. They appear in the margins of others' documents, in the records kept of them by administrators and missionaries, in the testimony of opponents, in the archaeology of daily life
- The "standard" version of any story has been shaped by who told it first and who kept telling it
- Official myth-making is not deliberate lying — it is usually sincere belief, formed by the selective attention that is inevitable when one is telling one's own story

**The novelist's civic function:** Historical fiction can tell the story that official history omitted — the defeated side, the silenced voice, the inconvenient truth that doesn't fit the national self-image. This is one of the most important things historical fiction can do. But it must be grounded in the same rigorous research as any other historical work — because the obligation to truth does not diminish because the subject was previously ignored.

**The "we weren't there until we got there" problem:** A recurring distortion in official history: as far as the dominant group is concerned, no history happened in a place until they arrived. Indigenous peoples had politics, trade, alliances, votes, and complex social structures before any colonial observer recorded them. The novelist who follows the logic of what must have been true — and researches the evidence that survives — is doing more honest history than the official version.

---

## The Fiction/History Boundary

### What Is Permissible Fiction
- **Invented scenes** within the documented life: domestic moments, meals, walks, conversations for which no record survives but which are consistent with everything documented
- **Interior monologue** for real historical figures, provided it is consistent with everything documented about their beliefs, temperament, and the worldview of their era
- **Invented dialogue** grounded in documented consciousness, the moment's political and social context, and the period's idiom
- **Invented secondary characters** who move alongside real events without altering them
- **Subplots and relationships** that do not contradict the documented record

### What Is Not Permissible
- Altering documented historical events to suit your plot
- Attributing to real historical figures beliefs, actions, or words that contradict the documented record
- Suppressing known historical facts that complicate your narrative, without acknowledgment
- Presenting as documented fact what is actually invention

**The author's note:** For any novel that blends documented history with significant invention, an author's note stating the nature of the blend is an act of integrity toward the reader.

---

## The Partisan Principle

Every historical novelist has an axe to grind. You are writing this story because it matters to you, and it matters in a specific direction. This is not a weakness — it is the engine of the work. A story written with no perspective is a story with nothing to say.

**What this means practically:**
- Know your axe. Name it to yourself before you write the first scene.
- A conscious bias is a managed bias. An unexamined bias is a distortion you cannot see.
- Facts are the check on the axe. When the facts push back against your preferred interpretation, follow the facts. The more you live, the better you'll write — but only if you let experience revise your assumptions.

**The spectrum of honest partisanship:**
- Emphasising the experiences of previously silenced groups: legitimate
- Choosing to tell the story of the underdog, the peacemaker, the defeated: legitimate
- Selecting evidence to support a predetermined conclusion while suppressing contrary evidence: not legitimate

**The partisan grows:** A writer who began telling the heroic version of a story and, through continued research and living in the subject, comes to see the complexity behind the heroism — that writer's evolution is itself a story about how understanding history is always in revision. The axe does not stay the same across a writing life. It is sharpened and adjusted by the facts encountered along the way.

---

## The Then-and-Now Principle

History is not confined to the past. It is always in revision, always relevant, always pressing into the present through the consequences of what happened then.

The finest historical fiction illuminates the present through the past — not by drawing explicit parallels, but by building a story so true and so fully realised that the reader discovers the resonance for themselves.

**The reader's reward:** A reader who finishes the novel knowing something they did not know before — something that changes how they understand the world they live in — has received what good historical fiction uniquely delivers. No other form does this as well.

**Questions to test Then-and-Now resonance:**
- What problem, pattern, or human truth does this historical moment share with the present?
- What have we been told is settled that this story shows is not?
- What have we been taught to understand in one way that this story reveals to be something else?
- If a reader comes away thinking "that explains why this is the way it is" — what should that insight be?

Build the answer into the story's architecture. Do not deliver it as a lesson. Let the reader discover it.

---

## Credibility With Readers

Historical fiction readers divide into those who read for the story and those who read to learn the history. Both groups will stop reading if you lose their trust. The second group stops faster and tells others.

**Trust-building practices:**
- Research so thoroughly that specialist readers find the texture convincing
- When inventing, invent in the direction of verisimilitude
- When departing from documented fact for structural reasons, acknowledge it in an author's note
- When handling contested historical territory, research both sides

The reward: readers who say "I felt like I was there" and "I know it must have happened just that way." That is the highest praise the craft offers.

---

## Cross-Links

- For source types and collection methods: → **references/research-methods.md**
- For the worldview of characters (period cosmology): → **references/character-biography.md**
- For the language of historical credibility: → **references/period-voice.md**
- For applying truth calibration in the audit: → **SKILL.md, nodes F and G4**
- For communication speed as a credibility issue: → **references/research-methods.md, communication speed section**

# Research Methods Reference

*Called from: SKILL.md nodes B1–B4*
*Links back to: SKILL.md B-node; truth-calibration.md; character-biography.md; period-voice.md*

## The Research Disposition

Research is not a phase. It is a posture held throughout the entire project. Writing surfaces questions; questions demand research; research changes the writing. The process is circular and continuous.

**The governing rule:** If it doesn't make sense, keep digging. A story that doesn't quite cohere is missing a piece. The missing piece is almost always in the historical record, waiting to be found.

**The novelist's edge:** A generalist who casts a wide net sometimes finds what a specialist, looking only at their own field, cannot see. Novelists who have caught historians getting things wrong have usually done so by following the logic of human nature further than the specialist was willing to go — or by importing knowledge from a different field that illuminated the gap.

---

## Source Hierarchy

### Primary Sources (Most Valuable)
Documents created at or near the time of events by people with direct knowledge:

- **Personal diaries and journals** — the most intimate; record daily weather, meals, health, mood, and small events official histories omit. A pocket diary recording each day's weather, visitors, and physical complaints grounds the novelist in the mundane texture that no secondary source can provide
- **Letters** — reveal what was on people's minds in their own unguarded voice; note address forms, tone with different correspondents, and what is conspicuously *not* mentioned
- **Pension records and military rosters** — demographic data; names, ages, origins, physical descriptions; what a soldier's service actually consisted of
- **Court depositions and legal records** — disputes reveal social norms; testimony records actual speech patterns of people who could not write
- **Newspaper accounts** — the beginning of the historical record for any event; full of errors, bias, and the details that later, smoother histories omit
- **Ship logs and official reports** — precise dates, weather, routes, orders; the bureaucratic record of what actually happened versus what was supposed to happen
- **Account books and inventories** — what things cost; what people owned; the texture of economic life that no narrative history captures
- **Medical records and case notes** — treatments, symptoms, mortality; the body of the past
- **Contemporary encyclopaedias and almanacs** — the state of knowledge of an era; invaluable anti-anachronism tools

### Secondary Sources (Valuable, Filtered)
Works by historians who have already synthesised primary materials. Use multiple secondary sources, note where they conflict, and follow the footnotes back to the primary record they are based on.

### Living Sources
- **Historians and archivists** — know of unpublished materials; can direct searches
- **Re-enactors and living-history practitioners** — embody practical knowledge of period crafts, weapons, clothing, and movement that no text conveys
- **Descendants** — carry oral history, family documents, and the corrective knowledge of those who lived inside a story the rest of the world got wrong
- **Specialists in period medicine, agriculture, law, technology** — a single conversation prevents months of error

---

## Communication Speed as Research and Plot

This section belongs in research because it must be discovered and mapped *before* writing begins — not patched in during revision.

In your historical period, how fast did news travel? This is not a texture question. It is a **structural plot question**. A character cannot know something that has not yet physically reached them. Getting this wrong is a plot-level anachronism that breaks verisimilitude at the deepest level.

**Research and record:**
- What were the available modes of long-distance communication in your period and region? (Signal fires, drums, semaphore flag stations, express riders on post roads, sailing packets, river couriers, the optical telegraph, the electrical telegraph if applicable)
- What was the realistic travel time for news between the key locations in your story? Map this on your chronological wall chart
- Were there institutional controls on information? (War censorship; a Secretary of War forbidding a telegraph message to the enemy; a postmaster's route that missed certain towns; a ship captain who carried dispatches exclusively)
- Were there places where information moved faster than elsewhere? (Telegraph lines follow specific routes; post roads stop at specific inns; riverboats service specific landings)

**Add to your wall chart:** A "news arrives" column noting when each significant event would actually become known to each location relevant to your story.

**Plot implications:** A scene in which a character acts on information they could not yet have received is a plot hole, not merely a factual error. Conversely, a character making a fatally wrong decision because the correct information did not arrive in time is one of history's great dramatic structures — and it is only available to a writer who has done this research.

**Communication technology timeline (reference points):**
- Before the optical telegraph (Chappe, 1790s): all land communication travels at the speed of a horse on the best available roads
- Optical telegraph networks (France 1790s, Britain 1796, US signalling during the Revolution): line-of-sight relay stations; fast but limited to specific routes and daylight
- Electrical telegraph (Morse, operational US 1844; transatlantic cable, 1866): transforms news speed across wired regions; but note which areas are not yet connected
- The news blackout: in any period before instant communication, authorities could suppress information by controlling couriers. Research whether this applied to your period and place

---

## Data Organisation Systems

### The Chronological Wall Chart
A physical or digital master timeline for the novel. Grid structure:

- **Vertical axis:** Timeline at the granularity needed (years, months, weeks, or days)
- **Horizontal columns:** Everything relevant to your story — weather, military events, political developments, protagonist's movements, secondary characters' movements, agricultural seasons, epidemics, moon phases, news-arrival times, communication events
- **Each cell:** A pencilled note with a reference abbreviation pointing back to the source

**Additional charts:** Genealogical chart; geographic route maps; battle maps; a perpetual calendar for calculating days of the week for any calendar date.

The wall chart externalises the novel's architecture. A scene written on a Monday cannot inadvertently place a character somewhere they were documented to be on a Tuesday — or give them knowledge of an event whose news could not have arrived until Wednesday.

### The Character Biography File
→ **See: `references/character-biography.md`** for the full biography template.

### The Period Vocabulary List
A running log of:
- Words confirmed for the period (with source and year of first use)
- Words confirmed as *not yet existing* in the period
- Phrases and idioms collected from primary sources, especially those evocative enough for dialogue or narration
- Communication-related vocabulary: what was the word for the express rider? The semaphore operator? The town crier? The broadsheet printer?

### The Source Conflict Log
When two credible sources disagree:
1. Note both claims and their sources
2. Research the conflict (provenance, proximity to the event, motive)
3. Record your resolution
4. Apply the Beagle Test: which version makes better human sense?

---

## Genealogical Research

Genealogy is a gateway into social history of unusual intimacy. In tracing a lineage, the researcher passes through migration patterns, economic circumstances, naming conventions, marriage patterns, and mortality — the full texture of lives that left no other record.

**For writers including characters of marginalised ancestry:** Records for enslaved people, indigenous peoples, and immigrant communities were often incomplete, deliberately obscured, or destroyed. Oral history, mission records, census-era rolls, and church registers in colonial languages are starting points. The absence of records is itself historical data — a fact about who was considered worth counting.

**Native American genealogy specifics:** Most tribes are matrilineal — lineage traced through the mother. Indian naming in written records was frequently anglicised. Records are distributed among tribal rolls, federal agencies (historically unreliable and often deliberately incomplete), missionary archives, and county records. The federal government's interest in minimising the number of legally recognised tribal members has shaped the record profoundly.

**The Ditto problem:** Enslaved people listed in records as property under an owner's name — "John ditto, Mary ditto" — sometimes acquired "Ditto" as a surname when records were later interpreted. This kind of detail, discovered in research, is a window into a historical reality that no secondary source describes with the same force as the primary record itself.

---

## Research Traps

### The Kudzu Problem
A conscientious researcher can accumulate so much material that it obscures the original story. Signs of the kudzu problem:
- More research than story
- Reluctance to start writing because "more research is needed"
- Scenes becoming tours of research rather than lived experience
- A secondary source has become more interesting than the protagonist

**Cure:** Return to the gist. What is this story *about*? Organise data to serve that question.

### The Confirmation Trap
Researchers unconsciously seek material that confirms the story they already want to tell. Guard against it by actively seeking sources that challenge your assumptions, and letting the facts change the story rather than forcing the story to screen out inconvenient facts.

### The Omniscience Illusion
Knowing a great deal about a period creates the illusion of knowing everything. The most dangerous errors are not in areas the writer knows they don't know — they are in areas the writer assumes they understand. Treat assumptions as hypotheses. Verify them.

### When to Start Writing
Signs that it is time:
- Clear sense of gist and scope
- Functional chronological chart with communication-speed column
- Biographies for major characters
- Enough primary sources to ground the protagonist's consciousness in period reality
- Period vocabulary list sufficient for dialogue

When the draft raises a question, note it in a research queue and keep writing. Do not stop for details that can be filled in during revision. Stop only for facts that would require structural revision of what has already been written.

---

## The Retrospective Principle

Research never ends. A novelist who returns to a completed work after twenty years of continued research and living in the subject will find things to revise — not because the first draft was careless, but because understanding deepens through living. "The more you live, the better you'll write."

This is not a counsel of perfectionism — it is a counsel of humility. The first novel about a subject is the best you can do with the knowledge and experience you then possess. It is not the last word. The field of history itself keeps evolving. New primary sources are found. New scholarship recontextualises old records. Stay in the field.

---

## Cross-Links

- For evaluating source credibility: → **references/truth-calibration.md**
- For building character files from research: → **references/character-biography.md**
- For how research feeds sensory writing (especially yucky stuff): → **references/sensory-writing.md**
- For anti-anachronism vocabulary work: → **references/period-voice.md**
- For the audit that checks research quality: → **SKILL.md, nodes G1, G2**

---
name: historical-fiction-master
description: >
  Complete craft system for writing historical fiction with deep authenticity,
  sensory immersion, and verisimilitude. Use whenever anyone asks to write, draft,
  improve, critique, plan, or research historical fiction — period novels, historical
  short stories, alternative history, biographical fiction, frontier or war narratives,
  or any prose set in a recognisable past. Also triggers for: period dialogue, avoiding
  anachronism, sensory detail, period research, structuring a historical novel, real vs
  fictional characters, communication speed as plot, illiterate or child characters,
  social codes and mores, and why Then matters to Now. If the user mentions any past
  era, any historical figure, or any then-and-now project, use this skill. Consult
  before the period-texture-engine reference (`subskills/period-texture-engine/period-texture-engine.md`).
---

# Historical Fiction Master Skill

## Core Philosophy: Once Upon a Time It Was Now

The supreme goal of historical fiction is temporal immersion: making any past moment feel as immediate and pressing as the present. The reader must inhabit that world — not observe it from a museum corridor. This is achieved not by explaining history, but by *being inside* it.

The novelist differs from the historian in one critical way: the historian faces backward only. The novelist faces both ways simultaneously, carrying the reader into the present tense of any era. But that is only the beginning of the difference. The novelist can get inside the skin and the soul. The historian cannot invent what a person thought in the dark before a battle, or what they smelled when they opened a letter from home. The novelist can — and must.

**VERISIMILITUDE** — the appearance or semblance of truth — is the governing word. Print it large above your workspace. Everything in the craft serves it.

**THE RIVER OF TIME:** History is not a series of events. It is a river. The novelist stands in that river, sees backward and forward simultaneously, and knows that every story flows from what came before and into what comes after. A great historical novel does not merely visit the past — it shows the reader that the river is still running, that Then is still shaping Now.

> "The history doesn't stop. It's there from the first page to the last, and it's as accurate as research can make it. The fiction begins where research can't find or verify any more facts."

> "If you aren't in awe of language — if you take it for granted, if you're lazy and sloppy with it — you aren't fit to be a storyteller."

---

## Skill Map: How to Navigate This System

This is a networked skill, not a linear one. Every node links to others. You may enter at any point and follow the thread that best serves the work in front of you.

```
CORE PHILOSOPHY (River of Time / Verisimilitude / Fire of Language)
     │                                                      │
     ▼                                                      ▼
[A] IMMERSION ENGINE              [B] RESEARCH ARCHITECTURE
 └─ White Heat Principle            └─ B.S. Filter / Beagle Test
 └─ Period Texture (subskill)       └─ Data Taming
 └─ Sensory Writing (ref)           └─ Truth Calibration (ref)
 └─ Yucky Stuff principle           └─ Comm. Speed as Plot
     │           │                        │           │
     ▼           ▼                        ▼           ▼
[C] CHARACTER    [D] LANGUAGE       [E] STRUCTURE    [F] CREDIBILITY
 └─ White Heat    └─ Period Voice     └─ Gist/Scope   └─ Fact vs Fiction
 └─ Biography     └─ Dialogue         └─ Grabbers     └─ Then-and-Now
 └─ Illiteracy    └─ Codes & Mores   └─ Endings       └─ Axe to Grind
 └─ Children      └─ Comm. tech      └─ Arc/Plotting
     │                │                    │               │
     └────────────────┴────────────────────┴───────────────┘
                              │
                       [G] AUDIT PROTOCOL
                        └─ Anachronism / Comm. speed
                        └─ B.S. Filter sweep
                        └─ Sensory / Yucky stuff check
                        └─ Verisimilitude check
                        └─ Cliché / stereotype sweep
                        └─ Then-and-Now resonance check
```

**Navigation rule:** When drafting a passage → A → C → D in sequence. When evaluating a draft → G. When planning a novel → E → B → A. When the gist feels thin → F5 (Then-and-Now). All paths are bilateral.

---

## [A] Immersion Engine

*Calls: `subskills/period-texture-engine/period-texture-engine.md`; references/sensory-writing.md*

The immersion engine converts historical facts into lived experience. It operates on five principles.

### A1. The Now Principle
Write every scene as if it is happening *at this moment* to a person who does not know what comes next. Characters do not speak in hindsight. They speak in urgency, ignorance, hope, and fear. The reader time-travels by inhabiting that urgency, not by reading a summary of it.

**Test:** Can you remove every sentence that announces the reader is in the past? If yes, those sentences were wrong. The past must be *felt*, not announced.

### A2. The White Heat Principle
Research is drudgery done in daylight. Writing is fire that must be lit. Before setting down a scene, get stirred up — inhabit the character's skin, their soul, their heart and mind. Know them so completely that writing them is not a performance but a possession. The prose that results from this state has a different temperature from prose assembled methodically. Readers feel the difference.

**Practice:** Before writing any significant scene, spend five minutes inhabiting the character's body. What do they smell right now? What aches? What do they dread in the next ten minutes? Then write from inside that body, not from above it.

### A3. Material World Activation
→ **Proceed to: `references/sensory-writing.md`** for full five-sense deployment.
→ **Proceed to: `subskills/period-texture-engine/period-texture-engine.md`** for period object, social register, and constraint embedding.

Every scene needs at least one object the character interacts with that could not exist in any other era. Surfaces, textures, and materials ground time better than dates. Money, tools, transport, and food are the fastest period anchors. Do not label the object with its history; let the character use it.

### A4. The "Good Yucky Stuff" Principle
The biological, accidental, and disgusting details of historical life are not merely colourful — they are historically significant and dramatically indispensable. Maggots found in wounds before anyone understood infection. Vinegar rations issued to soldiers as medicine. Tobacco smoke blown into a patient's rectum as an enema. Cheese made from a calf's stomach lining. The use of urine to set dye. Human hair collected and woven into furniture.

These are the details that make a reader say *I was right there* — because they are the details that could not have been invented for effect. They carry the authority of the utterly specific.

**Rule:** In every chapter, ask: what is the yucky, the accidental, the biological, or the grotesque truth that no one thinks to include? Find it. Include it. It will do more work than three pages of setting description.

→ **Proceed to: `references/sensory-writing.md`** for activation technique.

### A5. The Five Senses as Architecture
Sight is overused. Smell is the most powerful memory trigger and the most neglected. Sound is constant in real life and almost always absent on the page. Taste and touch are the final intimacies that put the reader *inside* a body.

**Rule:** Each scene — minimum three senses, with one non-visual sense carrying dramatic weight.
→ **Proceed to: `references/sensory-writing.md`** for the full technique library.

---

## [B] Research Architecture

*Calls: `references/research-methods.md`; `references/truth-calibration.md`*

### B1. The Research Disposition
Research is not a phase. It is a posture held throughout the entire project. Every sentence written surfaces new questions. The goal is not completeness — it is the correct habit of mind: *if it doesn't make sense, keep digging.*

### B2. The B.S. Filter and the Beagle Test
A well-developed historical novelist possesses an active scepticism that fires when something in the record doesn't ring true. This is not cynicism — it is pattern-recognition built from wide reading and the habit of asking *why*.

**The Beagle Test:** Any historical account that doesn't quite cohere — where a behaviour seems inexplicable, a cause is missing, a detail doesn't fit — is missing a piece. Before accepting the gap as mere historical mystery, dig. The missing piece is almost always findable. A story that makes sense on the human level, even where documentary evidence is thin, has verisimilitude. A story that requires implausible behaviour does not.

**The novelist's edge:** A generalist who casts a wide net sometimes finds what the specialist, looking only at their own field, cannot see. A novelist's intuition, trained on human nature and shaped by wide reading, is a legitimate research instrument.

### B3. Communication Speed as Research and Plot
In your historical period, how did news travel? This is not merely a texture question — it is a *plot* question. A character cannot know what has not yet physically arrived. The speed of information shapes narrative possibility at a structural level.

Research and record for your period:
- What were the modes of long-distance communication? (Drums, semaphore flags, signal mirrors, express riders on horseback, post roads, sailing packets, river couriers, the telegraph if applicable)
- What was the realistic travel time for news between key locations in your story?
- What were the institutional controls on information? (War censorship, the Secretary of War forbidding a telegraph, a town crier, a broadsheet printer)
- What did characters *not yet know* at any given moment in the story — and how does that ignorance shape their decisions?

**Plot rule:** A character who acts on knowledge they could not yet possess has committed a structural anachronism. Map your information timeline alongside your event timeline.

→ **Proceed to: `references/research-methods.md`** for full source and data systems.

### B4. The Partisan Question
Every historical novelist has an axe to grind. Know yours. Name it. A conscious bias is a managed bias. The finest historical fiction often comes from a deliberate decision to tell the story that official history omitted — the defeated, the enslaved, the silenced. That is a legitimate and important axe. But facts are the check: they keep the axe honest.

**The partisanship spectrum:** Choosing to tell the story from the underdog's side — legitimate. Selecting evidence that confirms your preferred interpretation while suppressing contrary facts — not legitimate. The test: would you be comfortable if a deeply knowledgeable historian annotated every departure from the documented record in your novel?

---

## [C] Character Architecture

*Calls: `references/character-biography.md`*

### C1. The Actor Principle
Before writing a character, know them as an actor preparing to portray them. What did their voice sound like? What were their physical peculiarities — not idealisations, but the specific oddities? What did they believe about illness, fate, God, and human nature given the cosmology of their era?

A character's psychology must be *of their time*, not a modern mind in period costume. The sin of anachronism is most often committed not in objects but in consciousness.

### C2. The White Heat of Character
Getting inside a character's skin is not an intellectual exercise — it is an imaginative act of possession. A novelist who has truly inhabited a character can set them in motion and simply transcribe what they do. The character begins to surprise the writer. They refuse to do what the outline said. They find their own way to the scene's end. When this happens, the writer is doing the work correctly.

**Discipline:** Know the character's biography cold before writing a single scene. Then forget the biography and live in the moment with them.

### C3. The Body as Archive
A character's body is a document of everything that has happened to them. Old wounds that ache in cold. The chronic cough from too many winters in damp tents. The missing digit from a childhood accident with a saw. The way they favour one side from an old battle injury. A man sleeping propped upright because fluid in his lungs will not let him lie flat.

This is not decoration. It is the physical history of the person made present. Every scar, every limitation, every habitual gesture has an origin, and that origin is the historical record made flesh.

### C4. The Illiterate Protagonist
Through most of recorded history, most people could not read or write. A literate novelist writing an illiterate character must recognise that illiteracy is not merely the absence of a skill — it is a fundamentally different relationship with memory, knowledge, perception, and the world.

- An illiterate person navigates by memory, oral tradition, and sensory intelligence that a literate person has partially replaced with text
- Their knowledge of the world is communicated entirely through story, song, demonstration, and accumulated observation
- Their memory is extraordinary in domains where a literate person relies on notes
- Their spoken language is often richer, more idiomatic, and more rhythmically complex than that of educated literate speakers
- They perceive the landscape, the weather, and other people with an immediacy that literacy can dull

**The gift of illiteracy in fiction:** An illiterate protagonist sees everything with fresh, immediate, embodied intelligence. Nothing is abstracted onto a page. Everything is present, sensory, and alive.

### C5. Children in History
Children's cries are the unheeded voices in the rumble of history. When writing historical fiction, the novelist must resist the modern sentimentalisation of childhood. In most periods and most places, children were:

- Economic units — apprenticed, indentured, sent into mines and factories, sold into service
- Political assets — married off to seal alliances, traded as hostages, used as dynastic instruments
- Legal non-persons — subject to brutal discipline at home and school, with no rights against parents or masters
- War's especial victims — orphaned, conscripted, enslaved, evacuated, and killed in numbers that no official history adequately records

**The child narrator's specific power:** A child who witnesses adult events without understanding them fully creates the reader's dramatic irony — we know what the child does not. Their innocence is not ignorance but a different kind of sight: war seen without the adult's rationalisation; power seen without the adult's accommodation of it.

**The research obligation:** Whatever the period of your novel, research deep into the prevailing treatment of children. Do not project modern child-protection values backward. Show what was. That is more powerful than any editorial judgment.

→ **Proceed to: `references/character-biography.md`** for full biography template, POV protocols, and illiterate/child character guidance.

---

## [D] Language Craft

*Calls: `references/period-voice.md`; `subskills/period-texture-engine/period-texture-engine.md`*

### D1. Period Voice and Anti-Anachronism
Language is itself a historical artefact. Words available in 1692 are different from those in 1842. The vocabulary, idioms, and rhythms of speech mark time, class, region, and education as precisely as any costume.

**Critical trap:** The most damaging anachronisms are not in the vocabulary but in the *attitudes*. Modern self-awareness — the character who analyses their own psychology in 21st-century terms — is the commonest and most corrosive form of anachronism. A character's inner life must be filtered through the explanatory frameworks of their era: providence, humours, honour, fate, clan obligation, divine will.

→ **Proceed to: `references/period-voice.md`** for vocabulary checking, idiom lists, and anachronism categories.

### D2. Codes, Mores, and the Deadly Social Grammar
Every historical period had specific social codes that were not merely customs but life-and-death structures. A novelist who does not know the operating code of their era's social grammar will write characters who blunder through it invisibly — and invisibly falsify the world.

**Duelling:** From the 16th through the 19th century, a gentleman who could not control his tongue might find himself on a foggy morning field facing steel or a pistol ball. Newspaper editors were regularly called to the "field of honour" for editorials that we would consider routine criticism today. This single fact changes every scene of public debate, political argument, or personal insult in those centuries.

**Research the specific code for your era:** What are the rituals of challenge and submission? What insults are forgivable and which are not? What triggers formal satisfaction? Who is exempt and who is not? How does class intersect with the code? These are not exotic details — they are the operating rules of the world your characters must navigate.

**Other period codes to research:** Blood feuds and their resolution protocols. Guild obligations and the consequences of violation. Religious oaths and their legal standing. The specific rules of hospitality in the culture. Taboos around food, touch, eye contact, or speech by sex or caste.

### D3. Dialogue That Earns Its Keep
Dialogue is sound. Read it aloud. If it sounds like a term paper wearing quotation marks, rewrite it.

**The forbidden:** characters describing what they are both looking at; characters explaining historical context to each other in ways no one actually speaks; adverbs attached to speech tags doing the work that tone and word choice should; eye dialect so aggressive it becomes unreadable.

**The period dialogue test:** Could this sentence have been said, in this place, at this moment, by a person of this class and education? If not, rewrite.

### D4. Description in Motion
Never stop the narrative to describe. Description happens *while things are happening*. The character's perception of the environment is itself action — it reveals their state of mind, class, fear, or desire. You convey the mountainness of a mountain better by having your character climb it than by having them stand and admire it.

### D5. The Language Obligation
Language is like fire: it enriches, illuminates, forever changes. Every writer who sets words down is part of the oldest human tradition — storytelling around the fire. To be lazy with language, to settle for the approximate word, to write "he said menacingly" when the dialogue itself should carry the menace, is a failure of that obligation. The precision of language is not pedantry — it is respect for the tradition you are joining.

**The adverb economy:** An adverb is a symptom of a weak verb. Search your vocabulary for the precise word first. Reserve adverbs for moments where they carry information no verb can.

---

## [E] Structure and Scope

### E1. Gist and Scope
Every historical novel needs two things clarified before serious writing begins:
- **Gist:** What is the heart of this story? What must it say? This is the emotional and moral weight that the narrative carries beyond its particulars.
- **Scope:** From when to when — and what are the consequences? The true scope includes what is gained or lost, grown or diminished, historically and personally.

**The scope rule:** A great story means more than it says. By the last page, the reader should understand something beyond the specific tale — about human nature, about the persistence of patterns, about why Then is still happening Now.

### E2. Then-and-Now: Why This Story Matters
Every historical novel has a contemporary resonance — a reason why this story from Then matters to a reader living Now. This is not propaganda. It is the test of whether the story has earned its existence.

The novelist's obligation is to discover and build in this resonance without announcing it. The reader who finishes the novel should think: *I didn't know that. Now I understand something about the world I live in.* Or: *This explains why that is the way it is.*

**Finding the Then-and-Now:** Ask — what problem, pattern, or human truth does this historical moment share with the present? What have we been told is settled that this story shows is not? What have we been taught to misunderstand?

### E3. The Practice Synopsis
Write a synopsis before the novel — not to constrain but to discover where you think the story begins and ends, who the protagonist is, and what the emotional arc looks like. The synopsis will be wrong. That is fine. It is a milestone, not a cage.

### E4. Grabber Openings
The opening must be *immediate* and *full of portent*. Avoid throat-clearing — the scenic prologue, the genealogical backstory, the authorial explanation.

**Grabber types:** birth, first combat, a sound in the dark, a discovery, an arrival, a departure, a death that raises questions, a scream, an approaching threat, a decision already made — all thrusting the reader into motion already in progress.

**The highest standard:** A great opening establishes an image, a situation, and a physical relationship between protagonist and world that the ending will echo, complete, and transform. The reader who reaches the last page and recognises the opening image transformed has experienced the full arc of the craft.

**The opening test:** Remove the first page. If nothing essential is lost, the story begins on page two.

### E5. Endings and the Circular Arc
A great historical novel does not simply stop — it *completes*. The ending should resonate with the opening. An image, a gesture, a physical detail that appeared at the start returns transformed. The protagonist who lay prone in one posture at the beginning lies prone in the same posture at the end — but everything that has happened between those two moments makes the second moment carry the weight of the whole story.

**The craft obligation:** Before writing the final scenes, return to the opening. What image, phrase, or physical detail established the world? How can the ending transform that same image into its completion?

### E6. The Plotting Problem
Historical fiction has a structural constraint the novelist of pure invention does not: the facts. You cannot alter known history to serve your plot. Instead, plot lives in:
- The fictional characters woven alongside real events
- The interior lives of real people (their fears, loves, doubts)
- The moments *between* recorded events
- The subplots of invented witnesses to history

This constraint is also a gift: the historical record provides structure, stakes, and consequences that no invention could fully match.

---

## [F] Credibility and Truth-Management

*Calls: `references/truth-calibration.md`*

### F1. The Hard Question
Where does history stop and fiction begin? The history never stops. The fiction fills every gap research cannot close — but in *pursuit* of the truth, not in substitution for it.

### F2. Invented Scenes Within Real Events
You may — must — invent meetings, conversations, meals, walks, arguments, and domestic moments of which no record survives. These are not lies. They are *likely truths*: consistent with everything documented, filling what would otherwise be vacuum.

**The verisimilitude test:** Would it be strange if this incident *didn't* happen, given what we know? If yes, it has verisimilitude.

### F3. Dialogue Fabrication
Ground invented dialogue in: documented letters and journals (what was on their minds), the political and social concerns of the moment, the period's cosmology and idiom.

### F4. Truth Modification Awareness
History is always being modified — by memory, politics, the survivors who tell it, the conquerors who publish it. Official history is shaped by those with the power to shape it. The missing voices — the defeated, the enslaved, the oral-tradition keepers — are often more revealing than the official record. Your own bias as narrator is itself a historical fact about *your* time.

Know your axe. Wield it with awareness. Facts keep you honest.

### F5. The Then-and-Now Obligation
Historical fiction serves its highest purpose when it illuminates the present through the past. A reader who learns from your novel that piracy in Jefferson's era was shaped by the same geopolitical tensions as piracy in our own; that the border crisis has roots in a 19th-century war fought for causes the official textbooks prettified; that Lewis and Clark could not have succeeded without the knowledge and generosity of the people official history reduced to obstacles — that reader has received a gift that no other literary form delivers as well.

**The obligation:** Build the Then-and-Now resonance into the story's architecture, not as a lesson delivered by a character but as a consequence that the reader discovers for themselves.

---

## [G] Audit Protocol

Run this on any draft, scene, or passage before considering it complete.

### G1. Anachronism Sweep
Check every:
- Object, technology, or material for period accuracy
- Word or phrase for first-use date (modern psychological vocabulary is the commonest trap)
- Belief, attitude, or psychological concept for era-appropriateness
- Reference to events, people, or institutions that did not yet exist
- **Communication technology:** does the character know something that could not yet have reached them given the speed of information in this era?

### G2. B.S. Filter Sweep
For each element that strikes you as "off" — a behaviour that seems odd, a cause that seems absent, a reaction that doesn't quite fit — apply the Beagle Test: stop, flag it, and dig before proceeding. A scene that doesn't quite make sense is a scene missing a piece of history.

### G3. Sensory Audit
For each scene:
- [ ] At least three senses deployed
- [ ] At least one non-visual sense carries dramatic weight
- [ ] Sound is present (ambient, musical, or mechanical)
- [ ] At least one smell where the scene involves bodies, kitchens, battlefields, nature, or close quarters
- [ ] Touch and temperature where the body is under stress
- [ ] At least one "yucky stuff" detail — the biological, accidental, or grotesque truth of the moment — per chapter

→ **Proceed to: `references/sensory-writing.md`** if boxes are unchecked.

### G4. Verisimilitude Check
For each invented element:
- [ ] Fits the documented character of the person?
- [ ] Fits the documented conditions of time and place?
- [ ] Would a nitpicking specialist find this plausible?
- [ ] Would it be stranger if this *didn't* happen?

### G5. Immersion Break Audit
Scan for sentences that pull the reader out of the scene's present tense:
- Authorial intrusions ("as we now know")
- Explanatory parentheses that caption objects instead of using them
- Modern idiom or attitude in a period character's voice
- Scenery-pause description that halts narrative momentum

Every immersion break must be rewritten or deleted.

### G6. Cliché, Stereotype, and Social Code Sweep
- [ ] No stock villain or stock hero
- [ ] No recycled regional caricatures in dialogue
- [ ] No hackneyed phrases (and verify they existed in the period)
- [ ] No period-costume modern minds
- [ ] Period-specific social codes (honour, duelling, guild, religious obligation) present and structurally active?

→ Flag every cliché; substitute with a specific, researched, original observation.

### G7. Period Texture Spot-Check
→ **Proceed to: `subskills/period-texture-engine/period-texture-engine.md`** if any absent:
- [ ] At least one period-specific material object per scene, physically used
- [ ] Social register visible in speech or behaviour
- [ ] At least one constraint (social, economic, gendered, institutional) shaping action

### G8. Then-and-Now Resonance Check
- [ ] Does this story have a contemporary resonance the reader will discover for themselves?
- [ ] Has the story's gist been built into the architecture, not delivered as a lecture?
- [ ] Will a reader close this book knowing something about the present they did not know before?

---

## Subskill and Reference Map

| File | Purpose | When to Consult |
|------|---------|-----------------|
| `subskills/period-texture-engine/period-texture-engine.md` | Material culture, social register, constraint, communication speed | Any scene lacking grounded period texture; G7 failures |
| `references/sensory-writing.md` | Full five-sense library; yucky stuff technique; original simile | A3–A5 deployment; G3 failures |
| `references/research-methods.md` | Source types, data organisation, genealogy, comm. speed research | B1–B3 work; planning phase |
| `references/truth-calibration.md` | Credibility, source conflict, partisan question, novelist's edge | F-node work; source evaluation |
| `references/period-voice.md` | Period vocabulary, dialect, anachronism categories, social codes, dialogue | D-node work; G1 and G6 failures |
| `references/character-biography.md` | Full biography template, white heat, illiteracy, children, POV | C-node work; new character creation |

---

## Quick-Reference Rules

Post these at your workstation.

1. **Once upon a time it was now.** The past must be felt, never announced.
2. **Write to their senses.** Always and in everything. Including the yucky stuff.
3. **Get inside the skin.** Write in a white heat of imaginative possession, not from above.
4. **The history never stops.** Fiction fills the gaps; it does not replace the record.
5. **If it doesn't make sense, keep digging.** Develop and trust your B.S. filter.
6. **Know how fast news travels.** A character cannot know what has not yet arrived.
7. **Describe in motion.** Never stop the narrative to describe.
8. **Earn every piece of dialogue.** It is sound, not a memo.
9. **The sin of anachronism is most often in the mind, not the object.**
10. **Know your axe.** A conscious bias is a managed bias. Facts keep you honest.
11. **A great story means more than it says.** Then illuminates Now.
12. **Be worthy of language.** It is the oldest and most essential human technology.

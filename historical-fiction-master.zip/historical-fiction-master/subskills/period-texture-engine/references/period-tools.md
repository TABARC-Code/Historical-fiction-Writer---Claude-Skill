# Period Tools

*Companion reference for the period-texture-engine subskill*
*Links to: sensory-writing.md for activation; period-voice.md for language and codes*

## Material Detail Toolkit

Every object must be era-specific, embedded in action, and activating at least one non-visual sense where possible.

**Light:** rush dip, tallow candle, beeswax candle, whale-oil lamp, pitch torch, resin torch, cresset, lantern with horn panels (not glass)
**Fire-making:** tinder box (flint, steel, char cloth, tinder), bellows, hearth chain, trivet, fire irons, salamander iron
**Writing:** quill, penknife (to cut and repair quills), pounce (sand to dry ink), inkhorn, wax seal and seal ring, sand bottle, blotter, vellum vs rag paper vs wood pulp paper (date accordingly)
**Clothing feel:** rough wool chafing skin, clammy wet deerskin, the torturous constriction of stays, identical boots (no left/right until mid-19th century), linen that clings when wet
**Food vessels:** trencher, horn cup, earthenware crock, pewter plate, wooden bowl, gourd dipper
**Health materials:** vinegar ration (soldiers), camphor (moth and medicinal), mercury (syphilis treatment), laudanum (opium and alcohol), leeches, cupping glass, tobacco smoke enema pipe, catgut sutures, maggots as wound cleaners
**Communication objects:** broadsheet, gazette, dispatch, wax-sealed letter, warrant with counter-signature, semaphore flag, signal mirror, express rider's horn, town crier's bell, signal cannon

## Social Register Toolkit

**Gentry / ruling class:** formal address by title and estate name; assumption of service; no apology to subordinates without dramatic purpose; specific leisure (field sports, correspondence, music, cards); the management of tenants and servants as a daily activity
**Merchant / artisan:** pride in specific trade knowledge; economic anxiety of the middle position; careful cultivation of credit and reputation; specific craft vocabulary worn naturally in speech
**Labouring / rural:** idiom rooted in agricultural or craft work; direct speech without ornament; pragmatic relation to the body and its needs; specific regional phrases that place the speaker without phonetic spelling
**Military:** rank-specific address (what you call a sergeant vs an ensign vs a colonel); chain of command visible in every interaction; the specific vocabulary of the service branch and era
**Clerical / religious:** the specific vocabulary of the faith and institution; the social authority of the office; the obligations of the living or the rule; the characteristic rhetorical structure of sermon and prayer that enters everyday speech

## Constraint Toolkit

**Social:** gossip as surveillance; the cost of visible deviation; who watches, who tells, who acts; the specific social death that follows transgression in this era and class
**Economic:** debt as social condition; specific cost of staples relative to wages; what a character cannot do because they cannot afford it; the difference between cash, credit, barter, and obligation
**Legal:** coverture (a married woman's legal non-personhood), entail (property rights), impressment (forced military service), vagrancy law, guild regulation, apprenticeship indenture, the legal standing of written contract vs spoken oath
**Religious:** the specific demands of the faith; the consequence of public impiety; the inner structure of genuine belief that shapes decisions no external observer sees
**Gendered:** the specific permissions and prohibitions by sex; tactical workarounds; the cost of exceeding the sanctioned role
**Period honour codes:** duelling (the challenge, the second, the terms, the weapons choice as the challenged party's privilege), blood feud protocols, the specific insults that trigger satisfaction in this era and class

## Communication Technology Toolkit by Era

**Before optical telegraph (pre-1790s):**
All land communication at the speed of a horse on the best available road. Express riders change horses at post stations; the post road stops at specific inns; a broadsheet arrives when a bookseller decides to print it.

**Optical telegraph era (1790s–1840s):**
Line-of-sight relay stations; fast but limited to specific routes, daylight, and clear weather. Messages can be transmitted across France in hours — but only on the state-controlled semaphore network.

**Electrical telegraph era (1840s onward):**
Transforms news speed across wired regions — but note precisely which towns and routes are connected, and which are not. News can travel instantly from New York to Washington; the same news takes two weeks to reach a frontier settlement by express rider.

**Institutional control:** In any period, information can be deliberately suppressed. Map who controls the communication channels in your story's world and what their interests are.
